const elform = document.querySelector('.form');
const elInput = document.querySelector('.input');
const elList = document.querySelector('.list');
const elTextarea = document.querySelector('.textarea')
const elModal = document.querySelector('.modal')
const elModalTop = document.querySelector('.top')

const fetchArr = async() => {

    const response = await fetch('http://127.0.0.1:3000/todos');
    const data = await response.json()

    renderArr(data, elList);
    modalArr(data, elModal)
    modalNameArr(data)

}

fetchArr()

function renderArr(arr, list){
    arr?.forEach(i => {
        let newName = document.createElement('h1') 
        let newParagraph = document.createElement('p') 
        let newBtn = document.createElement('button') 

        newBtn.className = 'fas fa-close'
        newBtn.type = 'button'
        newBtn.dataset.id = i.id

        newBtn.addEventListener('click', (e) => {

            let dataId = e.target.dataset.id

            fetch(`http://127.0.0.1:3000/todos/${dataId}`,{
                method: 'DELETE'
            })
        })

        newName.textContent = i.name
        newParagraph.textContent = i.content

        newName.appendChild(newBtn)
        list.appendChild(newName)
        list.appendChild(newParagraph)
    });
}
function modalNameArr(arr){

    arr?.forEach(i => {
        let newName = document.createElement('h1') 
        let newBtn = document.createElement('i') 

        newBtn.className = 'fas fa-close'
        newBtn.type = 'button'
        newBtn.dataset.id = i.id

        newBtn.addEventListener('click', (e) => {
            document.querySelector('.modal-container').style.display = 'none'
        })

        newName.textContent = i.name
        elModalTop.appendChild(newName)
        elModalTop.appendChild(newBtn)
    });
}

function modalArr(arr, list){

    arr?.forEach(i => {
        let newParagraph = document.createElement('p') 
        newParagraph.textContent = i.content
        list.appendChild(newParagraph)
    });
}

elform.addEventListener('submit', e => {
    e.preventDefault()

    fetch('http://127.0.0.1:3000/todos', {
        method: 'POST',
        headers:{
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            id: new Date().getTime,
            name: elInput.value.trim(),
            content: elTextarea.value.trim(),
            isComlited: false
        })
    })
})

elList.addEventListener('click', () => {
        document.querySelector('.modal-container').style.display = 'block'
})